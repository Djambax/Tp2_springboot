package fr.devavance.tp_spring_boot_partie2.beans;

import lombok.Data;

@Data
public class Employee {
    private int id;

    public Employee(int id, String name, String address, String email, String phone, Fonction fonction) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.email = email;
        this.phone = phone;
        this.fonction = fonction;
    }

    private String name;
    private String address;
    private String email;
    private String phone;

    private Fonction fonction;

}

