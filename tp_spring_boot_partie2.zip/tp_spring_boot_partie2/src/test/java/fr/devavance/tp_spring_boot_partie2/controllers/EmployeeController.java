package fr.devavance.tp_spring_boot_partie2.controllers;

import fr.devavance.tp_spring_boot_partie2.dao.IEmployeeDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller
public class EmployeeController {
    @Autowired
    private IEmployeeDAO employeeDAO;

    public String findAllEmployee(Model model){
        model.addAttribute("employees",employeeDAO.findAll());
        return "view_employees" ;
    }

}
