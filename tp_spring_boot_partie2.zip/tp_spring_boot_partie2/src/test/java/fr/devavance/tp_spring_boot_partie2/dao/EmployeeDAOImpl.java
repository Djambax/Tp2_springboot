package fr.devavance.tp_spring_boot_partie2.dao;

import fr.devavance.tp_spring_boot_partie2.beans.Employee;
import fr.devavance.tp_spring_boot_partie2.beans.Fonction;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import java.util.ArrayList;
import java.util.List;

@Component
public class EmployeeDAOImpl implements IEmployeeDAO{
    private List<Employee> employees = new ArrayList<>();
    @Override
    public List<Employee> findAll() {
        return new ArrayList<>(employees);
    }

    @Override
    public void add(Employee employee) {
        employees.add(employee);
        employees.add(new Employee(1,"Karim Mahmoud", "kmshawky20@gmail.com", "0097450413948", "Egypt", Fonction.DEV_WEB));
    }
}
