package fr.devavance.tp_spring_boot_partie2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpSpringBootPartie2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
