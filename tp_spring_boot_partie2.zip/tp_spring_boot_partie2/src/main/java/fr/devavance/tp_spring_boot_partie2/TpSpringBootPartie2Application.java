package fr.devavance.tp_spring_boot_partie2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpSpringBootPartie2Application {

	public static void main(String[] args) {
		SpringApplication.run(TpSpringBootPartie2Application.class, args);
	}

}
